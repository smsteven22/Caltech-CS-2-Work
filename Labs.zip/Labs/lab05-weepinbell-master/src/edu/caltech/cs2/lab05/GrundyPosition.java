package edu.caltech.cs2.lab05;

import java.util.*;

public class GrundyPosition {
    /*
     * Stores a mapping from the height of a pile to how many of those piles exist.
     * Does not include piles of size less than three.
     */
    private SortedMap<Integer, Integer> heapCounts; //have at least 3 tokens
    private static HashMap  <GrundyPosition, Boolean> memo = new HashMap<>();

    /**
     * Initializes a GrundyPosition with a single heap of height heapHeight.
     **/
    public GrundyPosition(int heapHeight) {
        this.heapCounts = new TreeMap<Integer, Integer>();
        this.heapCounts.put(heapHeight, 1); // we put one heap of heapheight
    }
    public GrundyPosition(SortedMap<Integer, Integer> map) {
        this.heapCounts = map;
    }

    /**
     * Returns a list of legal GrundyPositions that a single move of Grundy's Game
     * can get to.
     **/
    public List<GrundyPosition> getMoves() {
        List<GrundyPosition> acc = new ArrayList<>();
        for (int key : this.heapCounts.keySet()) { // no keys of size 0
                for (int i = key-1; i >=key/2+1; i--) {
                    TreeMap<Integer, Integer > clone = new TreeMap<>(this.heapCounts);
                    if (key - i != i) {
                        if (i >= 3) {
                            if (clone.containsKey(i)) {
                                clone.put(i, clone.get(i) + 1);
                            } else clone.put(i, 1);
                        }
                        if (key - i >= 3) {
                            if (clone.containsKey(key - i)) {
                                clone.put(key - i, clone.get(key - i) + 1);
                            } else clone.put(key - i, 1);
                        }
                        if (clone.get(key) == 1) {
                            clone.remove(key);
                        } else clone.put(key, clone.get(key) - 1);
                        //}
                    }
                    GrundyPosition g = new GrundyPosition(clone);
                    acc.add(g);
                }
        }
        return acc;
    }

    public boolean isTerminalPosition() {
        //if you only have 1 pile with 3
        return getMoves().size()==0;
    }

    public boolean isPPosition() {
        if (memo.containsKey(this)){
            return memo.get(this);
        }
       else{
            if (isTerminalPosition()) {
                memo.put(this, true);
                return true;
            }
            List<GrundyPosition> temp = getMoves();
            for (GrundyPosition pos : temp) {
                if (!pos.isNPosition()) {
                    memo.put(this, false);
                    return false;
                }
            }
            memo.put(this, true);
        }
        return true;
    }

    public boolean isNPosition() {
        if (memo.containsKey(this)){
            return !memo.get(this);
        }
        else {
            if (isTerminalPosition()) {
                memo.put(this, true);
                return false;
            }
            List<GrundyPosition> temp = getMoves();
            for (GrundyPosition pos : temp) {
                if (pos.isPPosition()) {
                    memo.put(this, false);
                    return true;
                }
            }
            memo.put(this, true);
        }
        return false;
    }

    /**
     * Ignore everything below this point.
     **/

    @Override
    public int hashCode() {
        //everytime you call isPPosition, you want to save this in the map

       return this.heapCounts.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof GrundyPosition)) {
            return false;
        }
        return this.heapCounts.equals(((GrundyPosition) o).heapCounts);
    }

    @Override
    public String toString() {
        return this.heapCounts.toString();
    }
}