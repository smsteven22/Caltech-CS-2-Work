package edu.caltech.cs2.lab07;

import edu.caltech.cs2.libraries.StdDraw;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Maze {
    public int n;                 // dimension of maze
    public boolean[][] north;     // is there a wall to north of cell i, j
    public boolean[][] east;
    public boolean[][] south;
    public boolean[][] west;
    public boolean done = false;
    public Point end;
    private static final int DRAW_WAIT = 4;

    public Maze(int n, String mazeFile) throws FileNotFoundException {
        this.n = n;
        end = new Point(n / 2, n / 2);
        StdDraw.setXscale(0, n + 2);
        StdDraw.setYscale(0, n + 2);
        init();

        Scanner scanner = new Scanner(new File(mazeFile));
        while (scanner.hasNext()) {
            String line = scanner.nextLine();
            String[] tokens = line.split(" ");
            assert tokens.length == 3;
            String direction = tokens[0];
            int x = Integer.valueOf(tokens[1]);
            int y = Integer.valueOf(tokens[2]);
            switch (direction) {
                case "N":
                    north[x][y] = false;
                    break;
                case "S":
                    south[x][y] = false;
                    break;
                case "E":
                    east[x][y] = false;
                    break;
                case "W":
                    west[x][y] = false;
                    break;
                default:
                    break;
            }
        }
    }

    private void init() {
        // initialze all walls as present
        north = new boolean[n+2][n+2];
        east  = new boolean[n+2][n+2];
        south = new boolean[n+2][n+2];
        west  = new boolean[n+2][n+2];
        for (int x = 0; x < n+2; x++) {
            for (int y = 0; y < n+2; y++) {
                north[x][y] = true;
                east[x][y]  = true;
                south[x][y] = true;
                west[x][y]  = true;
            }
        }
    }

    // draw the maze
    public void draw() {
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.filledCircle(n / 2.0 + 0.5, n / 2.0 + 0.5, 0.375);
        StdDraw.filledCircle(1.5, 1.5, 0.375);

        StdDraw.setPenColor(StdDraw.BLACK);
        for (int x = 1; x <= n; x++) {
            for (int y = 1; y <= n; y++) {
                if (south[x][y]) StdDraw.line(x, y, x + 1, y);
                if (north[x][y]) StdDraw.line(x, y + 1, x + 1, y + 1);
                if (west[x][y]) StdDraw.line(x, y, x, y + 1);
                if (east[x][y]) StdDraw.line(x + 1, y, x + 1, y + 1);
            }
        }
        StdDraw.show();
        StdDraw.pause(1000);
    }

    // Draws a blue circle at coordinates (x, y)
    private void selectPoint(Point point) {
        int x = point.x;
        int y = point.y;
        System.out.println("Selected point: (" + x + ", " + y + ")");
        StdDraw.setPenColor(StdDraw.BLUE);
        StdDraw.filledCircle(x + 0.5, y + 0.5, 0.25);
        StdDraw.show();
        StdDraw.pause(DRAW_WAIT);
    }

    /*
     * Returns an array of all children to a given point
     */
    public Point[] getChildren(Point point) {
        //check if there is a wall north, south, east, west
        // if not move there
        ArrayList<Point> children  = new ArrayList<>();
        int y = point.y;
        int x = point.x;
        if (!this.north[x][y]){
            Point child_first = new Point(x, y+1);
            child_first.parent = point;
            children.add(child_first);
        }
        if (!this.west[x][y]){
            Point child_second = new Point(x-1, y);
            child_second.parent = point;
            children.add(child_second);
        }
        if (!this.east[x][y]){
            Point child_third = new Point(x+1, y);
            child_third.parent = point;
            children.add(child_third);
        }
        if (!this.south[x][y]){
            Point child_fourth = new Point(x, y-1);
            child_fourth.parent = point;
            children.add(child_fourth);
        }
        Point[] actual_Children = new Point[children.size()];
        int count=0;
        for (Point child: children){
            actual_Children[count] = child;
            count++;
        }
        /* TODO */
        return actual_Children;
    }

    public void solveDFSRecursiveStart() {
        Point start = new Point(1, 1);
        //selectPoint(start);
        solveDFSRecursive(start);
    }

    /*
     * Solves the maze using a recursive DFS. Calls selectPoint()
     * when a point to move to is selected.
     */
    private void solveDFSRecursive(Point point) {
        // start at the root and go north until you cannot anymore
        // use get children to find where you can
        if (this.done) {
            return;
        }
        selectPoint(point);
        //selectPoint(point);
        Point[] available_children = this.getChildren(point);
        for (int i = 0; i < available_children.length; i++) {
            if (available_children[i].equals(this.end)){
                this.done= true;
                selectPoint(available_children[i]);
                break;
            }
            if (!available_children[i].equals(point.parent)) {
                solveDFSRecursive(available_children[i]);
            }
        }
    }


    /*
     * Solves the maze using an iterative DFS using a stack. Calls selectPoint()
     * when a point to move to is selected.
     */
    public void solveDFSIterative() {
        //use a stack to do this
        Stack<Point> children  = new Stack<>();
        //keep pushing the children onto the top and then pop off the top one
        Point curr = new Point(1,1); //this is our start point
        children.push(curr);
        while (children.size()>0){
            Point look = children.pop();
            selectPoint(look);
            if (look.equals(end)){
                break;
            }
            //get the children of this and push them back onto the stack
            Point[] childofchild = this.getChildren(look);
            for (Point child:childofchild){
                if (!child.equals(look.parent)) {
                    children.push(child);
                }
            }
        }
        /* TODO */
    }


}

