package edu.caltech.cs2.lab03;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DecisionTree {
    private final DecisionTreeNode root;

    public DecisionTree(DecisionTreeNode root) {
        this.root = root;
    }

    public String predict(Dataset.Datapoint point) {
        return predictHelper(point, this.root).outcome;
    }

    private OutcomeNode predictHelper(Dataset.Datapoint point, DecisionTreeNode currNode) {
        if (currNode.isLeaf()) {
            return (OutcomeNode)currNode;
        }
        AttributeNode attNode = (AttributeNode)currNode;
        String attribute = attNode.attribute;
        String feature = point.attributes.get(attribute);
        return predictHelper(point, attNode.children.get(feature));
    }

    private static DecisionTreeNode id3Helper(Dataset dataset, List<String> attributes) {
        if (!dataset.pointsHaveSameOutcome().equals("") || attributes.isEmpty()) {
            OutcomeNode nodeReturn = new OutcomeNode(dataset.getMostCommonOutcome());
            return nodeReturn;
        }

        String a = dataset.getAttributeWithMinEntropy(attributes);
        List<String> f = dataset.getFeaturesForAttribute(a);
        Map<String, DecisionTreeNode> children = new HashMap<>();

        List<String> copyList = new ArrayList<>(attributes);
        copyList.remove(a);
        for (String feature : f) {
            Dataset points = dataset.getPointsWithFeature(feature);
            if (points.isEmpty()) {
                String common = dataset.getMostCommonOutcome();
                OutcomeNode child = new OutcomeNode(common);
                children.put(feature, child);
            }
            else {
                children.put(feature, id3Helper(points, copyList));
            }
        }
        AttributeNode nodeReturn = new AttributeNode(a, children);
        return nodeReturn;
    }

    public static DecisionTree id3(Dataset dataset, List<String> attributes) {
        return new DecisionTree(id3Helper(dataset, attributes));
    }

}
