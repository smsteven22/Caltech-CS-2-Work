package edu.caltech.cs2.lab03;

public interface DecisionTreeNode {
    boolean isLeaf();
}
