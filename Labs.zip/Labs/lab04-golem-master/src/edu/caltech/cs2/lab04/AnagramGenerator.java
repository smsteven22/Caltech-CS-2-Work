package edu.caltech.cs2.lab04;

import java.util.ArrayList;
import java.util.List;

public class AnagramGenerator {
    public static void printPhrases(String phrase, List<String> dictionary) {
        List<String> accumulator = new ArrayList<>();
        LetterBag phraseBag = new LetterBag(phrase);

        printPhrasesHelper(dictionary, accumulator, phraseBag);

        if (phraseBag.isEmpty()) {
            System.out.println("[]");
        }
    }

    private static void printPhrasesHelper(List<String> dictionary, List<String> accumulator, LetterBag phraseBag) {
        for (String word : dictionary) {
            LetterBag wordBag = new LetterBag(word);

            if (phraseBag.subtract(wordBag) != null) {
                accumulator.add(word);
                if (phraseBag.subtract(wordBag).isEmpty()) {
                    System.out.println(accumulator);
                }
                else {
                    printPhrasesHelper(dictionary, accumulator, phraseBag.subtract(wordBag));
                }
                accumulator.remove(word);
            }

        }
    }

    public static void printWords(String word, List<String> dictionary) {
        if (word == null) {
            throw new NullPointerException();
        }

        LetterBag wordBag = new LetterBag(word);

        for (String dict : dictionary) {
            LetterBag dictBag = new LetterBag(dict);
            if (wordBag.subtract(dictBag) != null && wordBag.subtract(dictBag).isEmpty()) {
                System.out.println(dict);
            }
        }
    }

}
